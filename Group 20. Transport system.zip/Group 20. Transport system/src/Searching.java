import java.io.PrintStream;
import java.util.ArrayList;


public class Searching {
    static ArrayList<Integer> list = new ArrayList();

    public Searching(ArrayList lis) {
        list = lis;
    }

    public static void list() {
        System.out.println("Select the search method you want to perform\n1.Linear Search\n2.Binary Search\n3.Exhaustive Search");
    }

    //Linear search is a search method which sequentially  check each element of the list until
    // a match is found
    public static int lSearch(int key) {
        for(int i = 0; i < list.size(); ++i) {
            if ((Integer)list.get(i) == key) {
                System.out.println("" + key + " is located at index: " + i);
                return i;
            }
        }

        System.out.println("" + key + " not found");
        return -1;
    }

    //Binary search works repeatedly dividing in half the portion of the list that could contain the item
    //until you've narrowed down the possible locations to just one
    public static void bSearch(int first, int last, int key) {
        for(int mid = (first + last) / 2; first <= last; mid = (first + last) / 2) {
            if ((Integer)list.get(mid) < key) {
                first = mid + 1;
            } else {
                if ((Integer)list.get(mid) == key) {
                    System.out.println("Element is located at index: " + mid);
                    break;
                }

                last = mid - 1;
            }
        }

        if (first > last) {
            System.out.println("Element is not found!");
        }

    }

    //Exhaustive search is a algorithmic paradigm that consists of systematically enumerating all possible
    // candidates for the solution

    public int bfSearch() {
        if (list.size() == 0) {
            return 0;
        } else {
            boolean numOfDigits = false;
            int evenNumCounter = 0;

            for(int j = 0; j < list.size(); ++j) {
                int numOfDigit = 0;

                int currNum;
                for(currNum = (Integer)list.get(j); currNum >= 10; ++numOfDigit) {
                    currNum /= 10;
                }

                if (currNum < 10) {
                    ++numOfDigit;
                }

                PrintStream var10000 = System.out;
                Object var10001 = list.get(j);
                var10000.println("Number of digits in " + var10001 + " is " + numOfDigit);

                while(numOfDigit > 1) {
                    numOfDigit %= 2;
                }

                if (numOfDigit == 0) {
                    ++evenNumCounter;
                }
            }

            return evenNumCounter;
        }
    }
}
