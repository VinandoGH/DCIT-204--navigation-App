import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Sorting {
    static ArrayList<Integer> list = new ArrayList();

    public Sorting(ArrayList lis) {
        list = lis;
    }

    public static void list() {
        System.out.println("Select your preferred sorting method\n1.QuickSort\n2.MergeSort\n3.BubbleSort\n4.RadixSort\n5.BucketSort");
    }

    public void qSort(int start, int end) {
        if (start < end) {
            int q = this.partition(start, end);
            this.qSort(start, q);
            this.qSort(q + 1, end);
        }

    }

    public ArrayList<Integer> getSortedArray() {
        return list;
    }

    int partition(int start, int end) {
        //System.out.println("\n---------Iteration Starts----------");
        //System.out.println("\nSorting Window from index number:" + start + " to " + end);
        int init = start;
        int length = end;
        Random r = new Random();
        int pivotIndex = nextIntInRange(start, end, r);
        int pivot = (Integer)list.get(pivotIndex);
        System.out.println("Pivot Element " + pivot + " at index:" + pivotIndex);

        while(true) {
            while((Integer)list.get(length) <= pivot || length <= start) {
                while((Integer)list.get(init) < pivot && init < end) {
                    ++init;
                }

                if (init >= length) {
                   // System.out.println("\n---------Iteration Ends---------");
                    return length;
                }

                int temp = (Integer)list.get(init);
                list.set(init, (Integer)list.get(length));
                list.set(length, temp);
                --length;
                ++init;
                //System.out.println("\nAfter Swapping");

                for(int i = start; i <= end; ++i) {
                    System.out.print(list.get(i) + " ");
                }
            }

            --length;
        }
    }

    static int nextIntInRange(int min, int max, Random rng) {
        if (min > max) {
            throw new IllegalArgumentException("Cannot draw random int from invalid range [" + min + ", " + max + "].");
        } else {
            int diff = max - min;
            if (diff >= 0 && diff != Integer.MAX_VALUE) {
                return min + rng.nextInt(diff + 1);
            } else {
                int i;
                do {
                    do {
                        i = rng.nextInt();
                    } while(i < min);
                } while(i > max);

                return i;
            }
        }
    }

    public ArrayList<Integer> getSorteArray() {
        return list;
    }

    public void mSort() {
        this.divide(0, list.size() - 1);
    }

    public void divide(int startIndex, int endIndex) {
        if (startIndex < endIndex && endIndex - startIndex >= 1) {
            int mid = (endIndex + startIndex) / 2;
            this.divide(startIndex, mid);
            this.divide(mid + 1, endIndex);
            this.merger(startIndex, mid, endIndex);
        }

    }

    public void merger(int startIndex, int midIndex, int endIndex) {
        ArrayList<Integer> mergedSortedArray = new ArrayList();
        int leftIndex = startIndex;
        int rightIndex = midIndex + 1;

        while(leftIndex <= midIndex && rightIndex <= endIndex) {
            if ((Integer)list.get(leftIndex) <= (Integer)list.get(rightIndex)) {
                mergedSortedArray.add((Integer)list.get(leftIndex));
                ++leftIndex;
            } else {
                mergedSortedArray.add((Integer)list.get(rightIndex));
                ++rightIndex;
            }
        }

        while(leftIndex <= midIndex) {
            mergedSortedArray.add((Integer)list.get(leftIndex));
            ++leftIndex;
        }

        while(rightIndex <= endIndex) {
            mergedSortedArray.add((Integer)list.get(rightIndex));
            ++rightIndex;
        }

        int i = 0;

        for(int j = startIndex; i < mergedSortedArray.size(); ++j) {
            list.set(j, (Integer)mergedSortedArray.get(i++));
        }

    }

    public void bSort() {
        boolean sorted = false;

        while(!sorted) {
            sorted = true;

            for(int i = 0; i < list.size() - 1; ++i) {
                if (((Integer)list.get(i)).compareTo((Integer)list.get(i + 1)) > 0) {
                    int temp = (Integer)list.get(i);
                    list.set(i, (Integer)list.get(i + 1));
                    list.set(i + 1, temp);
                    sorted = false;
                }
            }
        }

        System.out.println(list);
    }

    public static void rSort() {
        boolean NUM_BASE = true;
        int maximum = 0;
        ArrayList<ArrayList<Integer>> buckets = new ArrayList(10);

        int power;
        for(power = 0; power < 10; ++power) {
            buckets.add(new ArrayList());
        }

        for(power = 0; power < list.size(); ++power) {
            if ((Integer)list.get(power) > maximum) {
                maximum = (Integer)list.get(power);
            }
        }

        for(power = 1; maximum / power != 0; power *= 10) {
            int index;
            for(index = 0; index < list.size(); ++index) {
                ((ArrayList)buckets.get((Integer)list.get(index) / power % 10)).add((Integer)list.get(index));
            }

            index = 0;

            int ii;
            for(ii = 0; ii < buckets.size(); ++ii) {
                for(int jj = 0; jj < ((ArrayList)buckets.get(ii)).size(); ++jj) {
                    list.set(index, (Integer)((ArrayList)buckets.get(ii)).get(jj));
                    ++index;
                }
            }

            for(ii = 0; ii < buckets.size(); ++ii) {
                ((ArrayList)buckets.get(ii)).clear();
            }
        }

        System.out.println(list);
    }

    public static void bucketSort(int[] arr) {
        int max = max(arr);
        int min = min(arr);
        int numberOfBuckets = max - min + 1;
        List<List<Integer>> buckets = new ArrayList(numberOfBuckets);

        int index;
        for(index = 0; index < numberOfBuckets; ++index) {
            buckets.add(new ArrayList());
        }

        int[] var10 = arr;
        int var6 = arr.length;

        int value;
        for(int var7 = 0; var7 < var6; ++var7) {
            value = var10[var7];
            value = hash(value, min, numberOfBuckets);
            ((List)buckets.get(value)).add(value);
        }

        Iterator var11 = buckets.iterator();

        while(var11.hasNext()) {
            List<Integer> bucket = (List)var11.next();
            Collections.sort(bucket);
        }

        index = 0;
        Iterator var13 = buckets.iterator();

        while(var13.hasNext()) {
            List<Integer> bucket = (List)var13.next();

            for(Iterator var15 = bucket.iterator(); var15.hasNext(); arr[index++] = value) {
                value = (Integer)var15.next();
            }
        }

    }

    private static int hash(int elem, int min, int numberOfBucket) {
        return (elem - min) / numberOfBucket;
    }

    public static int max(int[] arr) {
        int max = arr[0];
        int[] var2 = arr;
        int var3 = arr.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            int value = var2[var4];
            if (value > max) {
                max = value;
            }
        }

        return max;
    }

    public static int min(int[] arr) {
        int min = arr[0];
        int[] var2 = arr;
        int var3 = arr.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            int value = var2[var4];
            if (value < min) {
                min = value;
            }
        }

        return min;
    }
}
