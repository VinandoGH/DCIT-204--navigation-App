//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered 204 Group 40



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length of your array");
        int l = sc.nextInt();
        System.out.println("Enter your values");
        ArrayList<Integer> list = new ArrayList(l);

        int choice;
        for(choice = 0; choice < l; ++choice) {
            list.add(sc.nextInt());
        }

        System.out.println(list);
        System.out.println("What operation do you want to perform? \n1.Search\n2.Sort");
        choice = Integer.parseInt(sc.next());

        do {
            System.out.println("Please enter the Value Again");
            choice = Integer.parseInt(sc.next());
        } while(choice > 3);

        int i;
        if (choice == 1) {
            System.out.println("Enter your search key,if none enter 0");
            int key = Integer.parseInt(sc.next());
            Searching myObj = new Searching(list);
            Searching.list();
            int sice = Integer.parseInt(sc.next());
            if (sice == 1) {
                Searching.lSearch(key);
            }

            if (sice == 2) {
                i = (Integer)list.get(0);
                int last = (Integer)list.get(list.size() - 1);
                Searching.bSearch(i, last, key);
            }

            if (sice == 3) {
                myObj.bfSearch();
            } else {
                System.out.println("Searching Done");
            }
        } else if (choice == 2) {
            Sorting myS = new Sorting(list);
            Sorting.list();
            int sorice = Integer.parseInt(sc.next());
            Iterator var12;
            if (sorice == 1) {
                myS.qSort(0, list.size() - 1);
                System.out.println("\n\nProcessed sorted Array");
                var12 = myS.getSortedArray().iterator();

                while(var12.hasNext()) {
                    i = (Integer)var12.next();
                    System.out.print("" + i + " ");
                }
            } else if (sorice == 2) {
                myS.mSort();
                System.out.println("\nSorted Array");
                var12 = myS.getSortedArray().iterator();

                while(var12.hasNext()) {
                    i = (Integer)var12.next();
                    System.out.print("" + i + " ");
                }
            } else if (sorice == 3) {
                myS.bSort();
            } else if (sorice == 4) {
                Sorting.rSort();
            } else if (sorice == 5) {
                int[] arr = list.stream().mapToInt((ix) -> {
                    return ix;
                }).toArray();
                Sorting.bucketSort(arr);
                System.out.println("Sorted array: " + Arrays.toString(arr));
            } else {
                System.out.println("Please enter a valid input");
            }
        }

    }
}
 