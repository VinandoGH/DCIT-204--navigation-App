
import java.util.Arrays;
        import java.util.Scanner;

public class SearchSortDemo {

    // Linear search algorithm
    public static int linearSearch(int[] arr, int key) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) {
                return i;
            }
        }
        return -1; // Element not found
    }

    // Binary search algorithm
    public static int binarySearch(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (arr[mid] == key) {
                return mid;
            } else if (arr[mid] < key) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1; // Element not found
    }

    // Merge sort algorithm
    public static void mergeSort(int[] arr) {
        if (arr.length < 2) {
            return;
        }

        int mid = arr.length / 2;
        int[] left = Arrays.copyOfRange(arr, 0, mid);
        int[] right = Arrays.copyOfRange(arr, mid, arr.length);

        mergeSort(left);
        mergeSort(right);

        merge(arr, left, right);
    }

    private static void merge(int[] arr, int[] left, int[] right) {
        int i = 0, j = 0, k = 0;
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }

        while (i < left.length) {
            arr[k++] = left[i++];
        }

        while (j < right.length) {
            arr[k++] = right[j++];
        }
    }

    // Bubble sort algorithm
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Selection sort algorithm
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }

    // Quick sort algorithm
    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }

    // Radix sort algorithm
    public static void radixSort(int[] arr) {
        int max = Arrays.stream(arr).max().getAsInt();
        for (int exp = 1; max / exp > 0; exp *= 10) {
            countingSort(arr, exp);
        }
    }

    private static void countingSort(int[] arr, int exp) {
        int n = arr.length;
        int[] output = new int[n];
        int[] count = new int[10];
        Arrays.fill(count, 0);

        for (int i = 0; i < n; i++) {
            count[(arr[i] / exp) % 10]++;
        }

        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        for (int i = n - 1; i >= 0; i--) {
            output[count[(arr[i] / exp) % 10] - 1] = arr[i];
            count[(arr[i] / exp) % 10]--;
        }

        System.arraycopy(output, 0, arr, 0, n);
    }

    // Insertion sort algorithm
    public static void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        int[] arr = new int[size];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            arr[i] = scanner.nextInt();
        }

        System.out.print("Enter the operation type (search, sort): ");
        String operationType = scanner.next();

        long startTime = System.nanoTime();

        int result = -1;

        if (operationType.equalsIgnoreCase("search")) {
            System.out.print("Enter the value to search: ");
            int key = scanner.nextInt();

            System.out.print("Enter the search algorithm type (linear, binary): ");
            String searchAlgorithmType = scanner.next();
            if (searchAlgorithmType.equalsIgnoreCase("linear")) {
                result = linearSearch(arr, key);
            } else if (searchAlgorithmType.equalsIgnoreCase("binary")) {
                mergeSort(arr);
                result = binarySearch(arr, key);
            } else {
                System.out.println("Invalid search algorithm type!");
                return;
            }
        } else if (operationType.equalsIgnoreCase("sort")) {
            System.out.print("Enter the sort algorithm type (merge, bubble, selection, quick, radix, insertion): ");
            String sortAlgorithmType = scanner.next();
            if (sortAlgorithmType.equalsIgnoreCase("merge")) {
                mergeSort(arr);
            } else if (sortAlgorithmType.equalsIgnoreCase("bubble")) {
                bubbleSort(arr);
            } else if (sortAlgorithmType.equalsIgnoreCase("selection")) {
                selectionSort(arr);
            } else if (sortAlgorithmType.equalsIgnoreCase("quick")) {
                quickSort(arr, 0, arr.length - 1);
            } else if (sortAlgorithmType.equalsIgnoreCase("radix")) {
                radixSort(arr);
            } else if (sortAlgorithmType.equalsIgnoreCase("insertion")) {
                insertionSort(arr);
            } else {
                System.out.println("Invalid sort algorithm type!");
                return;
            }
        } else {
            System.out.println("Invalid operation type!");
            return;
        }

        long endTime = System.nanoTime();

        System.out.println("Sorted array: " + Arrays.toString(arr));

        if (result != -1) {
            System.out.println("Element found at index " + result);
        } else {
            System.out.println("Element not found.");
        }

        long duration = (endTime - startTime);
        System.out.println("Time taken: " + duration + " nanoseconds");
    }
}
